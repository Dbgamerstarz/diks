import pygame
import cr8
import virus_1 as virus
import time
import random
pg=pygame.init()
virus=virus.Virus()
dna,cooldown,contagion,color,shape=virus.createVirus()
set=cr8.Set()
color=set.getColor(color)
print('dna='+str(dna)+' cooldown='+str(cooldown)+' infectivity='+str(contagion)+' color='+str(color))
screen=pygame.display.set_mode((600,600))
pygame.display.set_caption('A Viral Game')

clock=pygame.time.Clock()
playsound = pygame.USEREVENT + 1

pygame.time.set_timer(playsound,int(cooldown))
running=True
while running:
    print("running")
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type==(playsound):
            print("draw")
            pygame.draw.circle(screen,pygame.Color(color),(random.randint(0,600),random.randint(0,600)),int(contagion),int(int(contagion)/2))
        if random.randint(1,90)>=85:
            color=random.randint(1,9)
            color=set.getColor(color)
        if random.randint(1,100)>=96:
            contagion=random.randint(5,20)
            
    
    

    pygame.display.update()
    pygame.display.flip()
    clock.tick(60)
pygame.quit()
quit()

