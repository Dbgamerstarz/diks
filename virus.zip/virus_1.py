import random
class Virus():
	def createVirus(self):
		dna=random.randint(100000,999999)
		dna=str(dna)
		
		cooldown=dna[0]
		cooldown=cooldown+dna[1]
		contagion=dna[2]
		contagion=contagion+dna[3]
		color=dna[4]
		shape=dna[5]
		
		return dna,cooldown,contagion,color,shape
	
