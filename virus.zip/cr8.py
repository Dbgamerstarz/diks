class Set():
	def getColor(self,color):
		color=int(color)
		if color==0:
			color='red'
		if color==1:
			color='green'
		if color==2:
			color='blue'
		if color==3:
			color='pink'
		if color==4:
			color='yellow'
		if color==5:
			color='purple'
		if color==6:
			color='grey'
		return color
